var DELETE_EXISTING_EVENTS = true;
var DEDUPLICATOR_FILTER = "controlm20";

var CONTROL_M_USER = "username";
var CONTROL_M_HOST_NAME = "localhost";
var CONTROLM_PASSWORD_FILE = "conf/bmccontrolm.pwd";

// Specifies how many retries to preform if a error in the API occurs
// This is also used for API timeouts to perform a re-connect for the API
var API_NUMBER_OF_RETRIES = 3;

// API properties
var CTMEMAPI_PROPERTIES_FILE = "integrationservices/controlm20/ctmemapi.properties";
var JACORB_PROPERTIES_FILE = "integrationservices/controlm20/jacorb.properties";
var AUTHORIZATION_REQUEST_MAJOR_CODE = "407";
var AUTHORIZATION_REQUEST_MINOR_CODE = "1";

// Configuration for the amount of time to sleep between receiving a SHOUT Message and making the callback to the Control-M API for the job details
var SLEEP_PERIOD_BETWEEN_CALLBACK = 3000; // 3 seconds in milliseconds 
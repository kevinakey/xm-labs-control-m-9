importPackage(java.lang);
importPackage(java.util);
importPackage(java.io);
importPackage(Packages.com.bmc.ctmem.emapi);
importPackage(Packages.org.jacorb);

/*
Changes that were required to get this code working:
* moved declarations of this.gsrComp and this.gsrInvoker to the top of the init function (they were being used before they were declared, as far as I can tell)
* changed the initalization of this.gsrComp: it is now explicitly an object of type com.bmc.ctmem.emapi.GSRComponent
* specify the server name while initializing this.gsrComp ("vic-vw-ctrl-m") - this is the one change that suddenly made the registration start working.
* added "com.bmc.ctmem.emapi.GSR.name=VIC-VW-CTRL-M" to C:\xmatters\integrationagent-5.1.8.2\integrationservices\controlm25\ctmemapi.properties -- this may not be necessary, but was speficied in the ctrl-m api doc
* in the registerAPI function, changed the string.replace params to match the contents of EMAPI_register.xml (which is copied from C:\control-m\emapi-900\examples\xml\EMAPI_register.xml)
* in registerAPI, used a hard-coded string (instead of relying on the CONTROL_M_PASS which is decrypted from a file) to generate a passwordToken
* fixed the XML parsing logic that retrieves the userToken from the xmlResponse

*/



var ctmem = new Namespace("http://www.bmc.com/ctmem/schema800");
var soap = new Namespace("http://schemas.xmlsoap.org/soap/envelope/");

var ControlMAPI = BaseClass.extend(
{
  init : function ()
  {
    // Control-M API variables
    this.registeredAPI = false;
      this.gsrComp = new com.bmc.ctmem.emapi.GSRComponent( CONTROL_M_HOST_NAME );
//    this.gsrComp = new com.bmc.ctmem.emapi.GSRComponent("vic-vw-ctrl-m");  // must match the "Control-M Server Name" reported in Start Menu / Control-M Configuration Manager - case-sensitive
//    this.gsrInvoker;
    this.gsrInvoker = new com.bmc.ctmem.emapi.EMXMLInvoker( this.gsrComp );

    this.userToken = "";

    this.log = new Logger("ControlMAPI: ");
    this.initiateAPI();
    this.registerAPI();

    this.log.info("Control-M API initialization is complete.");
  },
  
  initiateAPI : function ()
  {
    log.info("Entering initiateAPI. \n\n*** You can safely ignore the following 3 ERROR and 5 WARN messages - properties will be loaded shortly. ***\n");
    var xmlResponse;
        
    try
    {
      // load the CORBA API properties files
      var propsOrb = new Properties();

	  
	  log.debug("Jacorb Properties File " + JACORB_PROPERTIES_FILE);
      propsOrb.load(new FileInputStream(new File(JACORB_PROPERTIES_FILE)));
      propsOrb.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
      propsOrb.setProperty("org.omg.CORBA.ORBSingletonClass", "org.jacorb.orb.ORBSingleton");
      
/*  Un-comment to see verbose information about the jacorb properties 

	var propsList = propsOrb.propertyNames();
	var propName, propValue;
	while ( propsList.hasMoreElements() ) {
		propName = propsList.nextElement().toString();
  		propValue = propsOrb.getProperty(propName);
		log.debug("\tProperty file list contains property with name: " + propName + " and value: " + propValue );
	}
	*/

      log.debug("About to invoke gsrInvoker init using properties from jacorb.properties");
      this.gsrInvoker.init(new Array(), propsOrb);
      
	  log.debug("CTMEMAPI Properties File " + CTMEMAPI_PROPERTIES_FILE);
	  
      var propsEm = new Properties();
      propsEm.load(new FileInputStream(new File(CTMEMAPI_PROPERTIES_FILE)));
      
      log.debug("About to add properties from ctmemapi.properties to gsrInvoker");
      this.gsrInvoker.setProperties(propsEm);

    }
    catch(e)
    {
      // handle invoke failures
      log.error("ERROR in initiateAPI register : " + e.toString());
    }
    
    log.info("Exiting initiateAPI");
  },

  registerAPI : function ()
  {
    log.info("Entering registerAPI");
    var xmlResponse;
    
    try
    {
	  log.debug("*** BuildPasswordString attempting to get passwordToken with decrypted password... " + CONTROL_M_PASS );
      var passwordToken = this.gsrInvoker.BuildPasswordString(CONTROL_M_PASS);
	  log.debug("*** BuildPasswordString retrieved passwordToken \n" + passwordToken);

      var xmlRequest = new Scanner( new File("integrationservices/controlm25/xmldata/EMAPI_register.xml") ).useDelimiter("\\A").next();

	// Note: the following parameters must match the ones in the local EMAPI_register file (copied from C:\control-m\emapi-900\examples\xml\EMAPI_register.xml)
      xmlRequest = xmlRequest.replaceAll("emuser", CONTROL_M_USER);
      xmlRequest = xmlRequest.replaceAll("empass", passwordToken);
	  //xmlRequest = xmlRequest.replaceAll("HOST NAME", CONTROL_M_HOST_NAME);
      xmlRequest = xmlRequest.replaceAll("EMAPI HOSTNAME", CONTROL_M_HOST_NAME);
      
	  log.debug("Preparing to send the following xmlRequest to the ctrl-m v.9 api: \n" + xmlRequest );
      xmlResponse = this.gsrInvoker.invoke(xmlRequest);
    }
    catch(e)
    {
      // handle invoke failures
      log.error("ERROR in registerAPI register : " + e.toString());
      return;
    }
    // handle xml response
    log.debug("Received the following response from the ctrl-m v.9 api: \n" + xmlResponse );
    
    var wsutil = new WSUtil();
    var response = new XML(wsutil.formatStringForE4X(String(xmlResponse)));

    log.debug("Extracting the user_token from the xmlResponse..." );
    this.userToken = (response.*::Body.*::response_register.*::user_token).toString();
    
    log.info("\tReceived the following user_token: " + this.userToken);
    log.info("Exiting registerAPI");
  },

  /**
   * This function will retrieve the control-m job details from
   * the server for a particular job based on the job's orderId.
   * The jobs details will then be put into the APXML.
   * @param orderId, this is the orderId of the job to retrieve
   * @param apxml
   */
  getJobDetailsForAPXML : function (orderId, apxml)
  {
    var xmlResponse;    
    log.info("getJobDetailsForAPXML entering - for orderId = " + orderId);
    
    // now try to get the job details
    try
    {
      var wsutil = new WSUtil();
      var retryAPI = true;
      var retries = 0;

      while((retries < API_NUMBER_OF_RETRIES) && retryAPI)
      {
        
        var xmlRequest = new Scanner( new File("integrationservices/controlm25/xmldata/EMAPI_act_retrieve_jobs.xml") ).useDelimiter("\\A").next();
        xmlRequest = xmlRequest.replaceAll("\\$USER_TOKEN\\$", this.userToken)
        xmlRequest = xmlRequest.replaceAll("\\$ORDER_ID\\$", orderId)
        
        log.debug("Calling gsrInvoker.invoke(xmlRequest) for xmlRequest " + xmlRequest);
        responseStr = this.gsrInvoker.invoke(xmlRequest);
      
        // get the response
        xmlResponse = new XML(wsutil.formatStringForE4X(String(responseStr))).soap::Body;
        
        // check for errors
        if ((xmlResponse.soap::Fault).length() > 0) {
          log.error("The following SOAP Fault has occurred " + xmlResponse.soap::Fault);
          
          xmlResponse = xmlResponse.soap::Fault;
          //determine if it is a Invalid User Token and we need to re-register for a new one
          var faultError = xmlResponse.detail.ctmem::fault_act_retrieve_jobs.ctmem::error_list.ctmem::error;
          var faultMajorCode = faultError.@ctmem::major;
          var faultMinorCode = faultError.@ctmem::minor;
          var faultErrorMessage = faultError.ctmem::error_message;
          
          // check to see if the user token has expired
          if (faultMajorCode == AUTHORIZATION_REQUEST_MAJOR_CODE && faultMinorCode == AUTHORIZATION_REQUEST_MINOR_CODE) {
            // try to register and rerun the request
            log.debug("SOAP Error for faultMajorCode " + faultMajorCode + " and faultMinorCode " + faultMinorCode + " with faultErrorMessage " + faultErrorMessage + " we will try to do a API re-register to get the User Token");
            this.registerAPI();
          } else {
            apxml.setToken("message", "The following SOAP Error occurred for the API request to request_act_retrieve_jobs: " + xmlResponse);
            retryAPI = false;
          }
        } else {
          xmlResponse = xmlResponse.ctmem::response_act_retrieve_jobs.ctmem::jobs.ctmem::job.ctmem::job_data;
          
          // exit the retry API loop as we have the response
          retryAPI = false;
        }
        retries++;
      }
    }
    catch(e)
    {
      // handle invoke failures
      log.error("ERROR in getJobDetailsForAPXML: " + e.toString());
    }
    
    log.debug("getJobDetailsForAPXML exiting with xmlResponse " + xmlResponse);
    return xmlResponse;
  },
  
  done : function ()
  {
    log.debug("Calling EMXMLInvoker.done()");
    EMXMLInvoker.done();
  },

});